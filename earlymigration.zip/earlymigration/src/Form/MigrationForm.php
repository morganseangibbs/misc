<?php

/*
  * @file
  * Contains \Drupal\earlymigration\Form\MigrationForm
  * (This tells Drupal this is a file that it needs to know about)
  */

// namespace used to avoid conflicts in case function or class name exists elsewhere
namespace Drupal\earlymigration\Form;

// Refers to Drupal core to import functionality of elements into module
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

// Provides an Email form to register for early migration to new website

// Extends functionality of Drupal's FormBase class
class MigrationForm extends FormBase {

  public function getFormId() {
    // Returns ID of form, as every form in Drupal is assigned an ID
    return 'migration_form';
  }

    // Function builds form by assigning $form variable, calls Drupal core interface and pulls form state
    public function buildForm(array $form, FormStateInterface $form_state) {

      // Tells function that $node variable will be built out of the URL for that node (only important when putting into database!)
      $node = \Drupal::routeMatch()->getParameter('node');
      $nid = $node->nid->value;

      // Builds dropdown menu for departments
      $form['example_select'] = array (
        '#title' => $this
          ->t('Select Department'),
        '#type' => 'select',
        '#options' => [
          'cardiology' => $this
            ->t('Cardiology'),
          'nephrology' => $this
            ->t('Nephrology'),
          'gynecology' => $this
            ->t('Gynecology'),
          'otolaryngology' => $this
            ->t('Otolaryngology'),
          'diagnostics' => $this
            ->t('Diagnostic Medicine'),
        ],
        '#description' => t('PLEASE only choose <em>Diagnostic Medicine</em> if you report to Dr. House Directly!!!'),
        '#required' => TRUE,
      );

      // Builds email input section of form
      $form ['email'] = array (
        // Use t() function so that string can be translated
        '#title' => t("Email Address"),
        '#type' => 'textfield',
        '#size' => 50,
        '#description' => t("Account information will be to the email address provided."),
        '#required' => TRUE,
      );

      // Builds name input section of form
      $form ['name'] = array (
        '#title' => t("Name"),
        '#type' => 'textfield',
        '#size' => 50,
        '#description' => t("Please enter your full name."),
        '#required' => TRUE,
      );

      // Builds UNID input section of form
      $form ['unid'] = array (
        '#title' => t("UNID (8-digit number)"),
        '#type' => 'number',
        '#size' => 8,
        '#description' => t("Please enter your University ID."),
        '#required' => TRUE,
      );

      // Builds submit button for form
      $form ['submit'] = array (
        '#type' => 'submit',
        '#value' => t('Register'),
      );

      // Passes node ID so Drupal knows which node form is in (AKA piece of individual content in Drupal)
      $form ['nid'] = array (
        '#type' => 'hidden',
        '#value' => $nid,
      );

      // Returns information gathered from functions above for next page
      return $form;
    }

      //
      public function validateForm(array &$form, FormStateInterface $form_state) {

        // Stores UNID input length, gives error if it does not equal 8
        $unid = $form_state->getValue('unid');
        $unidlength = strlen($unid);
        if ($unidlength != 8) {
          $form_state->setErrorByName('unid', t('The UNID entered must be 8 digits', array('%unid' => $unidlength)));
        }

        // Pulls value of mail from form, then utilizes a built-in email validator from Drupal
        $emailvalue = $form_state->getValue('email');
        if ($emailvalue == !\Drupal::service('email.validator')->isValid($emailvalue)) {
          $form_state->setErrorByName ('email', t("Invalid Email Address", array('%mail' => $emailvalue)));
        }

      }

    public function submitForm(array &$form, FormStateInterface $form_state) {
      drupal_set_message(t("Registration Successful"));
    }

}
